Dan Wortmann
CS 368
Program 1

As stated I assumed all parameter data types were correctly given as input.

I have implemented a growing database that expands to accommodate more books as needed.

Everything else is as described on the course page.
