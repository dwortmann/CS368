Dan Wortmann
CS 368 - Fall 2014 
Program 3

Nothing special here, just threw together the extra destructors,
copy constructors and copy assignments along with the helper
functions. Hopefully I didn't botch it up too much.
